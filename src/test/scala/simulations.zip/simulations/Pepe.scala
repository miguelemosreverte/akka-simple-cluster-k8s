package simulations 

import io.gatling.core.Predef._
import io.gatling.core.scenario.Simulation
import io.gatling.core.structure.{PopulationBuilder, ScenarioBuilder}
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder

import scala.concurrent.duration._
import scala.language.postfixOps


class Pepe extends Simulation {

    
    val baseURL = "http://192.168.99.100:30037"
    val httpProtocol = http.baseUrl(baseURL)
    val scenario1 = scenario("scenario1").exec(
        http("titulo lo que le quieras llamar a esa llamada http que vas a hacer")
        .get("/")
    )
    
    

    setUp(
        scenario1.inject(constantUsersPerSec(50) during (10 seconds))
        .protocols(httpProtocol)
    )
}